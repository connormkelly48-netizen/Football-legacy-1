/**
 * Display-only rounding for OVR and OVR-derived values (deltas, peaks).
 *
 * OVR can legitimately be fractional now — the hidden career-ceiling
 * taper multiplies growth by fractions like 0.15/0.3/0.55, and binary
 * floating point can't represent most of those exactly, so raw values
 * accumulate noise like 67.65000000000057. That precision is exactly
 * what we want to KEEP internally (it's what makes seasons of tiny
 * partial growth add up correctly over a career) — this only cleans up
 * how the number is shown, it never touches the stored value.
 */
export function formatOvr(value: number): string {
  const rounded = Math.round(value * 100) / 100;
  // Strip trailing zeros: 66 -> "66", 67.5 -> "67.5", 67.65 -> "67.65".
  return Number(rounded.toFixed(2)).toString();
}

/** Same rounding, but with an explicit "+" sign for positive deltas. */
export function formatOvrDelta(value: number): string {
  const formatted = formatOvr(Math.abs(value));
  return value >= 0 ? `+${formatted}` : `-${formatted}`;
}
