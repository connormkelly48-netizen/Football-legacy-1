import { OfferBias } from '../types';

export interface EventStorylineFollowUp {
  headline: string;
  offerBias?: OfferBias;
}

/**
 * EVENT-DRIVEN STORYLINES
 * -----------------------
 * Certain random events don't just change OVR — they change what the club
 * is thinking heading into the next transfer window. This maps a random
 * event id to a follow-up narrative beat (shown alongside the season's news
 * headline) and, optionally, an `offerBias` that reshapes the composition
 * of the next `generateClubOffers()` call.
 *
 * Only a representative set is wired up here; add more entries as needed —
 * any event id not present simply has no follow-up storyline.
 */
const EVENT_STORYLINES: Record<string, (clubName: string) => EventStorylineFollowUp> = {
  ev_neg_52_acl_injury: (clubName) => ({
    headline: `The manager at ${clubName} isn't confident you'll come back the same player. He's already signed a replacement, but doesn't want to cut you loose outright — he's advised you to go out on loan to prove your fitness before he commits to your future.`,
    offerBias: { label: 'Manager Recommends a Loan Move', loanCount: 3, permanentCount: 2, includeStay: true }
  }),
  ev_neg_53_broken_leg: (clubName) => ({
    headline: `${clubName}'s medical staff have cleared you, but the manager is wary of throwing you straight back into a title race. Expect interest from clubs willing to ease you back in.`,
    offerBias: { label: 'Rehab Move Recommended', loanCount: 2, permanentCount: 2, includeStay: true }
  }),
  ev_neg_51_long_term_injury: (clubName) => ({
    headline: `The long layoff has cost you your place in ${clubName}'s plans for now. The board would rather you rebuild sharpness elsewhere than sit on the bench.`,
    offerBias: { label: 'Club Wants You Rebuilding Form', loanCount: 2, permanentCount: 1, includeStay: true }
  }),
  ev_neg_56_loss_of_confidence: (clubName) => ({
    headline: `Whispers from inside ${clubName} suggest the club feels a change of scenery could be exactly what you need to rediscover your best form.`,
    offerBias: { label: 'Fresh Start Suggested', loanCount: 1, permanentCount: 3, includeStay: true }
  }),
  breakthrough_season: (clubName) => ({
    headline: `Your breakout campaign hasn't gone unnoticed. Europe's elite are already circling, and ${clubName} know they may not be able to keep hold of you for long.`,
    offerBias: { label: 'Elite Suitors Circling', loanCount: 0, permanentCount: 4, includeStay: true }
  })
};

export function getEventStorylineFollowUp(eventId: string | undefined | null, clubName: string): EventStorylineFollowUp | null {
  if (!eventId) return null;
  const fn = EVENT_STORYLINES[eventId];
  return fn ? fn(clubName) : null;
}
