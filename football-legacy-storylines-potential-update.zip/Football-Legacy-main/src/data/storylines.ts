import { Storyline, Club } from '../types';

/**
 * STORYLINES
 * -----------
 * Optional background flavor selected (or auto-assigned) at career creation.
 * A storyline's main mechanical effect is `gameTimeTrustSeasons`: the club
 * will keep giving the player near-normal minutes for that many seasons even
 * if their OVR doesn't yet justify a squad spot on paper — mirroring how a
 * real academy graduate or marquee kid signing gets patience a random
 * 59-rated trialist would never get.
 *
 * Eligibility is checked against the player's chosen starting OVR, age, and
 * the rating of the club they're joining, so the creation screen only offers
 * storylines that actually make sense for the setup the player picked.
 */

export const STORYLINES: Storyline[] = [
  {
    id: 'academy_product',
    title: 'Academy Product',
    descriptionTemplate:
      '{name} has come through {club}\u2019s academy since the age of 8. The club has groomed him for years and believes he can be the next superstar to graduate from their youth system.',
    maxOvr: 65,
    maxAge: 20,
    minClubRating: 78,
    gameTimeTrustSeasons: 3
  },
  {
    id: 'marquee_wonderkid_signing',
    title: 'Marquee Wonderkid Signing',
    descriptionTemplate:
      '{club} paid a significant fee to beat off competition for {name}\u2019s signature. The board has staked its reputation on this deal working out, and won\u2019t panic over a slow start.',
    maxOvr: 68,
    maxAge: 19,
    minClubRating: 82,
    gameTimeTrustSeasons: 2
  },
  {
    id: 'hometown_hero',
    title: 'Hometown Hero',
    descriptionTemplate:
      '{name} grew up minutes from {club}\u2019s stadium and has supported the club his whole life. The fanbase has adopted him as one of their own before he\u2019s even played a senior minute.',
    maxOvr: 70,
    maxAge: 22,
    gameTimeTrustSeasons: 2
  },
  {
    id: 'relegation_gamble',
    title: 'The Relegation Gamble',
    descriptionTemplate:
      'With the first team underperforming and money tight, {club} has thrown {name} into the fire out of necessity rather than pure faith. Sink or swim.',
    maxOvr: 66,
    minClubRating: 60,
    gameTimeTrustSeasons: 2
  },
  {
    id: 'manager_project',
    title: "The Manager's Pet Project",
    descriptionTemplate:
      'The head coach personally pushed for {name}\u2019s arrival and has told the press he\u2019ll build the team\u2019s future around him. As long as this manager is in charge, {name} plays.',
    maxOvr: 72,
    maxAge: 23,
    gameTimeTrustSeasons: 3
  },
  {
    id: 'returning_loanee',
    title: 'The Returning Loanee',
    descriptionTemplate:
      '{name} spent last season out on loan proving himself, and {club} has recalled him with a plan to finally give him a real run in the first team.',
    minAge: 19,
    maxOvr: 74,
    gameTimeTrustSeasons: 1
  },
  {
    id: 'late_developer_believer',
    title: 'A Late Developer, But They Believe',
    descriptionTemplate:
      '{name} took longer than most to break through, but {club}\u2019s recruitment staff are convinced there\u2019s a late-blooming talent here worth being patient with.',
    minAge: 21,
    maxAge: 26,
    maxOvr: 70,
    gameTimeTrustSeasons: 2
  }
];

interface CreationEligibilityInput {
  ovr: number;
  age: number;
  club: Club;
}

export function getEligibleStorylines(input: CreationEligibilityInput): Storyline[] {
  return STORYLINES.filter(s => {
    if (s.minOvr !== undefined && input.ovr < s.minOvr) return false;
    if (s.maxOvr !== undefined && input.ovr > s.maxOvr) return false;
    if (s.minAge !== undefined && input.age < s.minAge) return false;
    if (s.maxAge !== undefined && input.age > s.maxAge) return false;
    if (s.minClubRating !== undefined && input.club.rating < s.minClubRating) return false;
    return true;
  });
}

export function rollAutoStoryline(input: CreationEligibilityInput): Storyline | null {
  const eligible = getEligibleStorylines(input);
  if (eligible.length === 0) return null;
  return eligible[Math.floor(Math.random() * eligible.length)];
}

export function renderStorylineText(storyline: Storyline, name: string, clubName: string): string {
  return storyline.descriptionTemplate
    .split('{name}').join(name)
    .split('{club}').join(clubName);
}
