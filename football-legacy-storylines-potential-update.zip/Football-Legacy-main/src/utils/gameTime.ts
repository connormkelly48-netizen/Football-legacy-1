import { Player, Club } from '../types';

/**
 * Rolls season appearances based on how far the player's OVR sits below the
 * club's rating. A big gap (e.g. a 59-rated player at an 84-rated club)
 * normally buries a player on the bench. An active storyline
 * (`storylineTrustSeasonsRemaining > 0`) overrides that squad-fit penalty,
 * simulating a club deliberately blooding a prospect it believes in despite
 * the numbers not yet justifying it.
 *
 * Shared by both manual season-by-season play (App.tsx) and Quick Fire
 * (quickfireEngine.ts) to keep the two modes in sync.
 */
export function rollSeasonAppearances(player: Player, club: Club): { apps: number; wasBenched: boolean } {
  const gap = club.rating - player.ovr;

  let floor = 28;
  let ceil = 38;

  if (gap > 20) {
    floor = 4;
    ceil = 14;
  } else if (gap > 12) {
    floor = 10;
    ceil = 20;
  } else if (gap > 6) {
    floor = 18;
    ceil = 28;
  }

  const wasBenched = ceil < 28;
  const trustActive = (player.storylineTrustSeasonsRemaining || 0) > 0;

  if (trustActive && wasBenched) {
    floor = Math.max(floor, 22);
    ceil = Math.max(ceil, 32);
  }

  const apps = Math.floor(Math.random() * (ceil - floor + 1)) + floor;
  return { apps, wasBenched: wasBenched && !trustActive };
}
