import { Player, Storyline } from '../types';

/**
 * Rolls a player's growth potential at creation.
 *
 * Requirements:
 * - Potential is fully random, not a fixed "+15" style offset.
 * - Floor is always startingOvr + 10 (never less).
 * - Distribution is weighted rather than uniform, so most rolls land close
 *   to the floor, with a genuine but rare shot at elite (90+) potential.
 *
 * IMPORTANT: a single exponential decay curve can't be reused as-is across
 * every starting OVR, because the floor itself moves closer to 90 as
 * starting OVR rises — e.g. a 78 OVR starter has floor 88, only 2 points
 * below the elite cutoff, so almost any smooth taper puts most of its mass
 * inside the elite band regardless of the decay rate (verified via Monte
 * Carlo: a naive single-curve version put a 78 OVR starter at a 70%+ chance
 * of 90+ potential). Instead this uses an explicit elite gate: a small,
 * roughly fixed chance (independent of starting OVR) to land in the 90-99
 * band at all, and otherwise tapers within the sub-elite range. That keeps
 * "elite" genuinely rare across the whole starting OVR spectrum instead of
 * ballooning for higher-rated wonderkids, while still letting a 50 OVR
 * starter roll 90+ on the same rare tail.
 */
const POTENTIAL_DECAY_RATE = 0.85;
const ELITE_GATE_CHANCE = 0.06; // matches this project's existing ~6% elite-rarity benchmark
const ELITE_BAND_FLOOR = 90;

function weightedRollInRange(low: number, high: number, decayRate: number): number {
  const range = high - low;
  if (range <= 0) return low;

  const weights: number[] = [];
  for (let i = 0; i <= range; i++) weights.push(Math.pow(decayRate, i));
  const totalWeight = weights.reduce((a, b) => a + b, 0);

  let roll = Math.random() * totalWeight;
  for (let i = 0; i <= range; i++) {
    if (roll < weights[i]) return low + i;
    roll -= weights[i];
  }
  return low;
}

export function rollPotential(startingOvr: number, extraFloorBonus: number = 0): number {
  const floor = Math.min(99, startingOvr + 10 + extraFloorBonus);
  if (floor >= 99) return 99;

  // Starting point already guarantees elite-tier potential (very high OVR
  // starts) - just taper within whatever range remains above the floor.
  if (floor >= ELITE_BAND_FLOOR) {
    return weightedRollInRange(floor, 99, POTENTIAL_DECAY_RATE);
  }

  const rollsIntoEliteBand = Math.random() < ELITE_GATE_CHANCE;
  if (rollsIntoEliteBand) {
    return weightedRollInRange(ELITE_BAND_FLOOR, 99, POTENTIAL_DECAY_RATE);
  }

  return weightedRollInRange(floor, ELITE_BAND_FLOOR - 1, POTENTIAL_DECAY_RATE);
}

export function rollPotentialForStoryline(startingOvr: number, storyline: Storyline | null): number {
  return rollPotential(startingOvr, storyline?.potentialFloorBonus || 0);
}

/**
 * The effective OVR ceiling growth logic should respect. Falls back to 99
 * for players/saves created before this field existed.
 */
export function getGrowthCeiling(player: Player): number {
  return typeof player.potential === 'number' && player.potential > 0 ? player.potential : 99;
}
